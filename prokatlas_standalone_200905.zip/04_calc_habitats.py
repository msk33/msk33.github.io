# USAGE: python 04_calc_habitats.py [OTU TABLE FILE NAME] 03_significant_hits.blasttab 05_results.txt

import pandas as pd
import sys

# Loading files and formatting otu table
input_otutable=sys.argv[1]
input_blasttab=sys.argv[2]
habitat_pref_scores=sys.argv[3]
df1=pd.read_csv(input_otutable,sep="\t")
df1["OTU_ID"]=df1.iloc[:,0]
otutable=df1.iloc[:,1:]

#(Step1) Environmental vectors (vec_e_hitcount)
## Each column in vec_e_hitcount represents the environmental vector (vector e) of one OTU
hit_list=pd.read_csv(input_blasttab,sep="\t",)
hit_list.columns=["OTU_ID","environment"]
vec_e_hitcount=pd.crosstab(hit_list.environment,hit_list.OTU_ID)

#(Step2) Convert to proportion for each query sequence
## Each column in vec_e_hitcount represents the "converted environmental vector" (vector E) of one OTU
vec_E_hitcount_proportion=vec_e_hitcount*100/vec_e_hitcount.sum()


#(Step3) Weighted average of environmental vectors
## Sort OTU table and environmental vectors
df2 = vec_E_hitcount_proportion.T.reset_index()
otutable_sorted=pd.merge(pd.DataFrame(df2.OTU_ID),otutable,on="OTU_ID",how="inner").sort_values("OTU_ID").drop("OTU_ID",axis=1).reset_index(drop=True)
vecE_sorted=pd.merge(pd.DataFrame(otutable.OTU_ID),df2,on="OTU_ID",how="inner").sort_values("OTU_ID").drop("OTU_ID",axis=1).reset_index(drop=True)

## Calculating the weighted average
df3=vecE_sorted.T.dot(otutable_sorted)
weighted_average_E=df3*100/df3.sum()



#(Step4) Correction for database size
## Indexing correction factors
df4=pd.read_csv("weight_correction.txt",sep="\t")
correction_factor={}
for i in range(len(df4)):
	correction_factor[df4.environment[i]]=df4.weight[i]

## Applying correction
corrected_E=pd.DataFrame()
number_of_environemental_categories=weighted_average_E.shape[0]
for i in range(number_of_environemental_categories):
	l=weighted_average_E.iloc[i,:]*correction_factor[weighted_average_E.index[i]]
	corrected_E=pd.concat([corrected_E,l],axis=1)


#(Step5) Convert to proportion (i.e. habitat preference scores)
habitat_pref=corrected_E.T*100/corrected_E.sum(axis=1)
habitat_pref.to_csv(habitat_pref_scores,sep="\t")
