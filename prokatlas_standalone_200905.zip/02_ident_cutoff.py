#USAGE: python 02_ident_cutoff.py -i [input_filename] -o [output_filename] --id 97 -l 150


import argparse
parser = argparse.ArgumentParser()

parser.add_argument('-i',"--infile",help="blasttab format")
parser.add_argument('-o',"--outfile",help="blasttab format")
parser.add_argument('--id',help="similarity threashold",default=97.0,type=float)
parser.add_argument('-l',help="length threshold",default=150,type=int)


args = parser.parse_args()

ident=args.id
len_threshold=args.l


import pandas as pd

f1pre1_reader=pd.read_csv(args.infile,header=None,sep="\t",chunksize=10**7) #split BLATTAB sequences by 10^7 rows to save memory usage

filtered_blasttab=pd.DataFrame() #output dataframe containing only "good" hits

for f1pre1 in f1pre1_reader:
	f1pre1.columns=["qseqid","sseqid","qlen","qstart","qend","slen","sstartp","sendp","nident","length"]
	
	# Filter hits by alignment length and sequence identity threshold
	length_filter = (f1pre1.length>=len_threshold) #Alignment length criteria
	identity_filter = f1pre1.nident/f1pre1.length>=0.01*ident #Sequence identity criteria
	f1pre2=f1pre1[length_filter&identity_filter].reset_index(drop=True) #Pick hits meeting both of the criteria
	
	# Arrange the directions of sequence hits
	sstart=[]
	send=[]
	for i in range(len(f1pre2)):
		subject=[f1pre2.sstartp[i],f1pre2.sendp[i]]
		sstart+=[min(subject)]
		send+=[max(subject)]

	f1ss=pd.Series(sstart)
	f1se=pd.Series(send)
	f1=pd.concat([f1pre2,f1ss,f1se],axis=1)
	f1.columns=["qseqid","sseqid","qlen","qstart","qend","slen","sstartp","sendp","nident","length","sstart","send"]
	
	# Remove hits with unaligned regions at the end of query or subject sequences
	# (See Fig.S1 of ProkAtlas paper)
	cond1=(f1.qlen-f1.qend<=2)|(f1.slen-f1.send<=2)
	cond2=(f1.qstart<=3)|(f1.sstart<=3)
	f2=f1[cond1&cond2]
	
	# Move "good hits" to `filtered_blasttab` (the final output dataframe)
	f3=f2.iloc[:,0:2]
	filtered_blasttab=pd.concat([f3,filtered_blasttab])



filtered_blasttab.to_csv(args.outfile,sep="\t",index=None,header=True)

