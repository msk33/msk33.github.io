README: How to use ProkAtlas (Updated August 20, 2020)
-------------------------------------------------

This document explains how to estimate microbial habitabilities using ProkAtlas.


What is included
- - - - - - - - - - -
1. This README file (README.txt).
2. ProkAtlas database (ProkAtlas.fa).
3. An internal source file for correcting the weights between environmental categories (weight_correction.txt).
4. Two python scripts for calculating prokaryotic habitability scores from a blasttab file (02_ident_cutoff.py; 04_calc_habitats.py).
5. Instruction for the formatting of input OTU table (OTUtable_guideline.pdf).
6. Schematic illustration of how 04_calc_habitats.py works (calc_habitats_illustartion.pdf).
7. Examples of input data (EXAMPLE_seqs.fa; EXAMPLE_otutab.txt).
8. Final output file (EXAMPLE_results.txt). Generated from EXAMPLE_seqs.fa and EXAMPLE_otutab.txt fed into ProkAtlas.




Requirements
- - - - - - - - - - -
 BLAST 2.3.0+
 Python 2.7 (Python3 would be okay but not guaranteed) and pandas



Input file
- - - - - - - - - - -
 TAB-spaced OTU table (.txt format)
 OTU representative sequences
 
 !!! PLEASE CHECK OTUtable_guideline.pdf TO AVOID UNPREDICTED ERRORS !!!



Usage
- - - - - - - - - - -
makeblastdb -dbtype nucl -in ProkAtlas.fa -hash_index -out prokatlas
blastn -db prokatlas -query [QUERY FILE NAME] -out 01a_result.blasttab -outfmt "6 qseqid sseqid qlen qstart qend slen sstart send nident length" -evalue 1e-10 -max_target_seqs 361474
sed -E 's/seq_.*barcodelabel=//g' 01a_result.blasttab > 01b_result.blasttab
python 02_ident_cutoff.py -i 01b_result.blasttab -o 03_significant_hits.blasttab --id 97 -l 150
# --id: Sequence similarity threashold (percentage); 97% is recommended
# -l: Alignment length threashold (bases); 150 is recommended
python 04_calc_habitats.py [OTU TABLE FILE NAME] 03_significant_hits.blasttab 05_results.txt



Output files
- - - - - - - - - - -
 01a_result.blasttab : Intermediate file (blasttab containing all hits). Could be very large.
                       No longer required once 01b_result.blasttab has been generated.
 01b_result.blasttab : Intermediate file (blasttab containing all hits). Could be very large.
 03_significant_hits.blasttab: Intermediate file (blasttab containing only significant hits).
 05_results.txt : Final outcome. Habitability compositions of prokaryotic community structure(s).


